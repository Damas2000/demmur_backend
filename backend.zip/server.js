const express = require('express');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const { cloudinaryConfig } = require('./config/cloudinaryConfig');
const cors = require('cors');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

dotenv.config(); // .env dosyasını yükleme

// Express uygulaması oluşturuluyor
const app = express();

app.use(bodyParser.json()); // Bu satırı `app` tanımlandıktan sonra yerleştirin

connectDB();
cloudinaryConfig();

// CORS Yapılandırması
app.use(cors({
    origin: 'https://harpiadamas.com.tr' // Frontend domainini buraya ekliyoruz
}));
app.use(express.json());

// Route dosyaları
const productRoutes = require('./routes/product');
const authRoutes = require('./routes/auth');
const customerRoutes = require('./routes/customer');
const collectionRoutes = require('./routes/collection');
const bannerRoutes = require('./routes/banner');
const cartRoutes = require('./routes/cartRoutes');
const favoritesRoutes = require('./routes/favorites');
const orderRoutes = require('./routes/orderRoutes');
const userRoutes = require('./routes/userRoutes');

// Veritabanına bağlanma
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log('MongoDB bağlantısı başarılı');
}).catch((error) => {
    console.error('MongoDB bağlantı hatası:', error);
});

// Rotalar
app.use('/api/admin', require('./routes/admin'));
app.use('/api/products', productRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/collections', collectionRoutes);
app.use('/api/customers', customerRoutes);
app.use('/api/banners', bannerRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/favorites', favoritesRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/users', userRoutes);

// Sunucuyu başlatma
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
