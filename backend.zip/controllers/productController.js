const Product = require('../models/Product');
const { cloudinary } = require('../config/cloudinaryConfig');

exports.getProducts = async (req, res) => {
    try {
        const products = await Product.find();
        res.json(products);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.getProductById = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) return res.status(404).json({ message: 'Product not found' });
        res.json(product);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.addProduct = async (req, res) => {
    try {
        const { name, price, description, stock, collection, sizes, colors } = req.body;
        let mainImageUrl = '';
        const imageUrls = [];

        if (req.files) {
            for (const file of req.files) {
                const result = await new Promise((resolve, reject) => {
                    const uploadStream = cloudinary.uploader.upload_stream(
                        { resource_type: "image", folder: "products" },
                        (error, result) => {
                            if (error) reject(error);
                            resolve(result);
                        }
                    );
                    uploadStream.end(file.buffer);
                });
                imageUrls.push(result.secure_url);
            }
            mainImageUrl = imageUrls[0];
        }

        const product = new Product({
            name,
            price,
            description,
            stock,
            collection,
            sizes: JSON.parse(sizes), // Bedenleri ayrıştır
            colors: JSON.parse(colors), // Renkleri ayrıştır
            mainImageUrl,
            imageUrls
        });

        await product.save();
        res.status(201).json(product);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.updateProduct = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) return res.status(404).json({ message: 'Product not found' });

        const { name, price, description, stock, collection, sizes, colors } = req.body;
        let mainImageUrl = product.mainImageUrl;
        const imageUrls = product.imageUrls.slice();

        if (req.files) {
            for (const file of req.files) {
                const result = await new Promise((resolve, reject) => {
                    const uploadStream = cloudinary.uploader.upload_stream(
                        { resource_type: "image", folder: "products" },
                        (error, result) => {
                            if (error) reject(error);
                            resolve(result);
                        }
                    );
                    uploadStream.end(file.buffer);
                });
                imageUrls.push(result.secure_url);
            }
            mainImageUrl = imageUrls[0];
        }

        const updatedProduct = {
            name,
            price,
            description,
            stock,
            collection,
            sizes: JSON.parse(sizes),
            colors: JSON.parse(colors),
            mainImageUrl,
            imageUrls
        };

        await Product.findByIdAndUpdate(req.params.id, updatedProduct, { new: true });
        res.json(updatedProduct);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.deleteProduct = async (req, res) => {
    try {
        const product = await Product.findByIdAndDelete(req.params.id);
        if (!product) return res.status(404).json({ message: 'Product not found' });

        res.json({ message: 'Product deleted' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.getProductsByCollection = async (req, res) => {
    try {
        const products = await Product.find({ collection: req.params.collectionName });
        res.json(products);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};
