const Collection = require('../models/Collection');
const uploadImage = require('../utils/uploadImage');

exports.getCollections = async (req, res) => {
    try {
        const collections = await Collection.find();
        res.json(collections);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.getCollectionById = async (req, res) => {
    try {
        const collection = await Collection.findById(req.params.id);
        if (!collection) return res.status(404).json({ message: 'Collection not found' });
        res.json(collection);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.addCollection = async (req, res) => {
    try {
        let imageUrl = '';
        if (req.file) {
            imageUrl = await uploadImage(req.file.path);
        }

        const collection = new Collection({
            ...req.body,
            imageUrl
        });

        await collection.save();
        res.status(201).json(collection);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.updateCollection = async (req, res) => {
    try {
        const collection = await Collection.findById(req.params.id);
        if (!collection) return res.status(404).json({ message: 'Collection not found' });

        let imageUrl = collection.imageUrl;
        if (req.file) {
            imageUrl = await uploadImage(req.file.path);
        }

        const updatedCollection = {
            ...req.body,
            imageUrl
        };

        await Collection.findByIdAndUpdate(req.params.id, updatedCollection, { new: true });
        res.json(updatedCollection);
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};

exports.deleteCollection = async (req, res) => {
    try {
        const collection = await Collection.findByIdAndDelete(req.params.id);
        if (!collection) return res.status(404).json({ message: 'Collection not found' });

        res.json({ message: 'Collection deleted' });
    } catch (error) {
        res.status(500).json({ message: 'Server error' });
    }
};
