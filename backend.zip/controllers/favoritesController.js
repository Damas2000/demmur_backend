const Favorite = require('../models/favorites'); // Favori modelini import edin
const Product = require('../models/Product'); // Ürün modelini import edin

// Favori durumu kontrol etme
exports.checkIfFavorite = async (req, res) => {
    try {
        const { productId } = req.params;
        const userId = req.user.id;

        const favorite = await Favorite.findOne({ userId });
        if (favorite && favorite.products.includes(productId)) {
            return res.status(200).json({ isFavorite: true });
        }

        return res.status(200).json({ isFavorite: false });
    } catch (error) {
        console.error('Favori durumu kontrol edilirken hata:', error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Favorilere ürün ekleme
exports.addToFavorites = async (req, res) => {
    try {
        const { productId } = req.body;
        const userId = req.user.id;

        let favorite = await Favorite.findOne({ userId });
        if (!favorite) {
            favorite = new Favorite({ userId, products: [] });
        }

        if (!favorite.products.includes(productId)) {
            favorite.products.push(productId);
            await favorite.save();
        }

        res.status(201).json({ success: true });
    } catch (error) {
        console.error('Favorilere eklerken hata:', error);
        res.status(500).json({ message: 'Server Error' });
    }
};

// Favorilerden ürün çıkarma
exports.removeFromFavorites = async (req, res) => {
    try {
        const { productId } = req.body;
        const userId = req.user.id;

        let favorite = await Favorite.findOne({ userId });
        if (!favorite) {
            return res.status(404).json({ message: 'Favorites not found' });
        }

        favorite.products = favorite.products.filter(
            (id) => id.toString() !== productId
        );

        await favorite.save();
        res.status(200).json({ success: true });
    } catch (error) {
        console.error('Favorilerden çıkarırken hata:', error);
        res.status(500).json({ message: 'Server Error' });
    }
};
exports.getFavorites = async (req, res) => {
    try {
        const userId = req.user._id; // Kullanıcı ID'sini alın
        const favorite = await Favorite.findOne({ userId }).populate('products'); // `userId` alanını kullanın

        if (!favorite) {
            return res.status(404).json({ message: 'Favorites not found' });
        }

        res.status(200).json(favorite.products);
    } catch (error) {
        console.error('Favori ürünler getirilirken hata:', error);
        res.status(500).json({ message: 'Favori ürünler alınırken hata oluştu' });
    }
};
